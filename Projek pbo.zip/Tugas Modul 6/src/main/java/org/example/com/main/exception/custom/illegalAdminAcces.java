package org.example.com.main.exception.custom;

public class illegalAdminAcces extends Exception {
    public illegalAdminAcces(String message) {
        super(message);
    }
}
