package org.example.com.main.util;

import javafx.stage.Stage;

public interface IMenu {
    public void menu(Stage stage);
}
