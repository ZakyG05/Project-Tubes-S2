package org.example.com.main.books;

/**
 * The {@code Book} class represents a book with details such as book ID, title,
 * author, category, stock, and duration.
 */
public class Book {
    private final String bookId;
    private String title;
    private String author;
    private String category;
    private int stock;
    private int duration;

    /**
     * Constructs a new {@code Book} with the specified book ID, title, author,
     * and stock.
     *
     * @param bookId  the unique identifier for the book
     * @param title   the title of the book
     * @param author  the author of the book
     * @param stock   the number of copies available in stock
     */
    public Book(String bookId, String title, String author, int stock) {
        this.bookId = bookId;
        this.title = title;
        this.author = author;
        this.stock = stock;
        this.duration = 0;
    }

    /**
     * Returns the book ID.
     *
     * @return the book ID
     */
    public String getBookId() {
        return bookId;
    }

    /**
     * Sets the title of the book.
     *
     * @param title the new title of the book
     */
    public void setTitle(String title) {
        this.title = title;
    }

    /**
     * Returns the title of the book.
     *
     * @return the title of the book
     */
    public String getTitle() {
        return title;
    }

    /**
     * Sets the author of the book.
     *
     * @param author the new author of the book
     */
    public void setAuthor(String author) {
        this.author = author;
    }

    /**
     * Returns the author of the book.
     *
     * @return the author of the book
     */
    public String getAuthor() {
        return author;
    }

    /**
     * Sets the stock of the book.
     *
     * @param stock the new stock of the book
     */
    public void setStock(int stock) {
        this.stock = stock;
    }

    /**
     * Returns the stock of the book.
     *
     * @return the stock of the book
     */
    public int getStock() {
        return stock;
    }

    /**
     * Sets the duration for which the book is lent.
     *
     * @param duration the new duration in days
     */
    public void setDuration(int duration) {
        this.duration = duration;
    }

    /**
     * Returns the duration for which the book is lent.
     *
     * @return the duration in days
     */
    public int getDuration() {
        return duration;
    }

    /**
     * Sets the category of the book.
     *
     * @param category the new category of the book
     */
    public void setCategory(String category) {
        this.category = category;
    }

    /**
     * Returns the category of the book.
     *
     * @return the category of the book
     */
    public String getCategory() {
        return category;
    }

    @Override
    public String toString() {
        return "Book{" +
                "bookId='" + bookId + '\'' +
                ", title='" + title + '\'' +
                ", author='" + author + '\'' +
                ", category='" + category + '\'' +
                ", stock=" + stock +
                ", duration=" + duration +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Book book = (Book) o;

        return bookId.equals(book.bookId);
    }

    @Override
    public int hashCode() {
        return bookId.hashCode();
    }
}
